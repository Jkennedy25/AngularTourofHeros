// Set the 'NODE_ENV' variable
process.env.NODE_ENV = process.env.NODE_ENV || 'development';

// Load the module dependencies
const configureMongoose = require('./config/mongoose');
const configureExpress = require('./config/express');
const configurePassport = require('./config/passport');

//add dependencies
const express = require('express');
const path = require('path');
const http = require('http');
const bodyParser = require('body-parser');

const app = express();

// Create a new Mongoose connection instance
const db = configureMongoose();

// Create a new Express application instance
const app = configureExpress();

// Configure the Passport middleware
const passport = configurePassport();

// Use the Express application instance to listen to the '3000' port
app.listen(3000);

// Log the server status to the console
console.log('Server running at http://localhost:3000/');

// Use the module.exports property to expose our Express application instance for external usage
module.exports = app;

// Get the body parser for parsing HTTP POST request data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
// Configure static file serving
app.use(express.static(path.join(__dirname, 'dist')));
app.use('/lib', express.static(path.resolve('./node_modules')));
// All other routes are sent the index file
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/index.html'));
});
// Get the port from the environment (default is 3000) and set it in Express.
 
const port = process.env.PORT || '3000';
app.set('port', port);
// Create the HTTP server.
 
const server = http.createServer(app);
 // Listen on provided port, on all network interfaces.
 
server.listen(port, () => console.log(`Server with Express running on localhost:${port}`));